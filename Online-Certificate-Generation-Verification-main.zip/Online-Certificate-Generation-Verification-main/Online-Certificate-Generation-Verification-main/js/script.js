$(document).ready(function(){
  $('.print').click(function(){
      $(this).hide();
      window.print();
    $(this).show();
  });
  
});